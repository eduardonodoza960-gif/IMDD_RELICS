package com.imdd.reliquias.registry;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.DyedColorComponent;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.component.type.UnbreakableComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

public class RelicFactory {
    public static final String RELIC_TAG = "imdd_relic_id";

    public static boolean isRelic(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        return customData != null && customData.copyNbt().contains(RELIC_TAG);
    }

    public static RelicType getRelicType(ItemStack stack) {
        if (!isRelic(stack)) return null;
        NbtComponent customData = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (customData == null) return null;
        return RelicType.fromId(customData.copyNbt().getString(RELIC_TAG));
    }

    private static MutableText styledName(String text, Formatting color) {
        return Text.literal(text).setStyle(
                Style.EMPTY
                        .withColor(color)
                        .withBold(true)
                        .withItalic(true)
                        .withUnderline(true)
        );
    }

    private static MutableText styledHexName(String text, int hexColor) {
        return Text.literal(text).setStyle(
                Style.EMPTY
                        .withColor(TextColor.fromRgb(hexColor))
                        .withBold(true)
                        .withItalic(true)
                        .withUnderline(true)
        );
    }

    private static ItemStack baseRelic(Item item, RelicType type, String name, Formatting color) {
        ItemStack stack = new ItemStack(item);
        stack.set(DataComponentTypes.CUSTOM_NAME, styledName(name, color));
        stack.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(false));
        stack.set(DataComponentTypes.DAMAGE_RESISTANT, new net.minecraft.component.type.DamageResistantComponent(net.minecraft.registry.tag.DamageTypeTags.IS_FIRE));

        NbtCompound nbt = new NbtCompound();
        nbt.putString(RELIC_TAG, type.getId());
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        return stack;
    }

    private static ItemStack baseHexRelic(Item item, RelicType type, String name, int hexColor) {
        ItemStack stack = new ItemStack(item);
        stack.set(DataComponentTypes.CUSTOM_NAME, styledHexName(name, hexColor));
        stack.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(false));
        stack.set(DataComponentTypes.DAMAGE_RESISTANT, new net.minecraft.component.type.DamageResistantComponent(net.minecraft.registry.tag.DamageTypeTags.IS_FIRE));

        NbtCompound nbt = new NbtCompound();
        nbt.putString(RELIC_TAG, type.getId());
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        return stack;
    }

    private static void addEnchantment(ItemStack stack, DynamicRegistryManager registries, RegistryKey<Enchantment> key, int level, boolean showInTooltip) {
        var lookup = registries.getOrThrow(RegistryKeys.ENCHANTMENT);
        RegistryEntry<Enchantment> entry = lookup.getOrThrow(key);
        ItemEnchantmentsComponent current = stack.getOrDefault(DataComponentTypes.ENCHANTMENTS, ItemEnchantmentsComponent.DEFAULT);
        ItemEnchantmentsComponent.Builder builder = new ItemEnchantmentsComponent.Builder(current);
        builder.add(entry, level);
        ItemEnchantmentsComponent built = builder.build();
        stack.set(DataComponentTypes.ENCHANTMENTS, built.withShowInTooltip(showInTooltip));
    }

    public static List<ItemStack> createAllRelics(DynamicRegistryManager registries) {
        List<ItemStack> list = new ArrayList<>();

        // 1. Slot 0 - Relíquia do Bizonho (<##C89B3C>&l&o&nRelíquia do Bizonho, Machado de Diamante, Repulsão 150 oculto, lore Repulsão 150)
        ItemStack s0 = baseHexRelic(Items.DIAMOND_AXE, RelicType.BIZONHO, "Relíquia do Bizonho", 0xC89B3C);
        addEnchantment(s0, registries, Enchantments.KNOCKBACK, 150, false);
        s0.set(DataComponentTypes.LORE, new LoreComponent(List.of(Text.literal("Repulsão 150").setStyle(Style.EMPTY.withColor(Formatting.GRAY).withItalic(false)))));
        list.add(s0);

        // 2. Slot 1 - Relíquia do Minerador (&e&l&o&nRelíquia do Minerador, Picareta de Netherite, Efficiency 10, Fortune 3)
        ItemStack s1 = baseRelic(Items.NETHERITE_PICKAXE, RelicType.MINERACAO, "Relíquia do Minerador", Formatting.YELLOW);
        addEnchantment(s1, registries, Enchantments.EFFICIENCY, 10, true);
        addEnchantment(s1, registries, Enchantments.FORTUNE, 3, true);
        list.add(s1);

        // 3. Slot 2 - Relíquia do Lenhador (Machado de Diamante, Efficiency 10, Sharpness 5)
        ItemStack s2 = baseRelic(Items.DIAMOND_AXE, RelicType.LENHADOR, "Relíquia do Lenhador", Formatting.AQUA);
        addEnchantment(s2, registries, Enchantments.EFFICIENCY, 10, true);
        addEnchantment(s2, registries, Enchantments.SHARPNESS, 5, true);
        list.add(s2);

        // 4. Slot 3 - Relíquia do Caçador (<##FF1F4D>&l&o&nRelíquia do Caçador, Besta, Perfuração 10, Rajada 3 (Multishot), Carga Rápida 5)
        ItemStack s3 = baseHexRelic(Items.CROSSBOW, RelicType.CACADOR, "Relíquia do Caçador", 0xFF1F4D);
        addEnchantment(s3, registries, Enchantments.PIERCING, 10, true);
        addEnchantment(s3, registries, Enchantments.MULTISHOT, 3, true);
        addEnchantment(s3, registries, Enchantments.QUICK_CHARGE, 5, true);
        list.add(s3);

        // 5. Slot 4 - Relíquia do Arqueiro (Besta, Quick Charge 5, Multishot 1, Piercing 10)
        ItemStack s4 = baseRelic(Items.CROSSBOW, RelicType.ARQUEIRO, "Relíquia do Arqueiro", Formatting.RED);
        addEnchantment(s4, registries, Enchantments.QUICK_CHARGE, 5, true);
        addEnchantment(s4, registries, Enchantments.MULTISHOT, 1, true);
        addEnchantment(s4, registries, Enchantments.PIERCING, 10, true);
        list.add(s4);

        // 6. Slot 5 - Relíquia da Sorte (&a&l&o&nRelíquia da Sorte, Pé de Coelho, encantamento escondido, dá Sorte 10)
        ItemStack s5 = baseRelic(Items.RABBIT_FOOT, RelicType.SORTE, "Relíquia da Sorte", Formatting.GREEN);
        s5.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        list.add(s5);

        // 7. Slot 6 - Relíquia do Guerreiro (&4&l&o&nRelíquia do Guerreiro, Espada de Netherite, Sharpness 10, Smite 5, Bane of Arthropods 5, Sweeping Edge 3, Knockback 3, Looting 3)
        ItemStack s6 = baseRelic(Items.NETHERITE_SWORD, RelicType.GUERRA, "Relíquia do Guerreiro", Formatting.DARK_RED);
        addEnchantment(s6, registries, Enchantments.SHARPNESS, 10, true);
        addEnchantment(s6, registries, Enchantments.SMITE, 5, true);
        addEnchantment(s6, registries, Enchantments.BANE_OF_ARTHROPODS, 5, true);
        addEnchantment(s6, registries, Enchantments.SWEEPING_EDGE, 3, true);
        addEnchantment(s6, registries, Enchantments.KNOCKBACK, 3, true);
        addEnchantment(s6, registries, Enchantments.LOOTING, 3, true);
        list.add(s6);

        // 8. Slot 7 - Relíquia da Defesa (&8&l&o&nRelíquia da Defesa, Escudo, Thorns 5, retribui 3.5 de dano + repulsão)
        ItemStack s7 = baseRelic(Items.SHIELD, RelicType.DEFESA, "Relíquia da Defesa", Formatting.DARK_GRAY);
        addEnchantment(s7, registries, Enchantments.THORNS, 5, true);
        list.add(s7);

        // 9. Slot 8 - Relíquia do Fim (<##E7E6B0>&l&o&nRelíquia do Fim, Élitra, Proteção 15 escondida + lore Proteção 15)
        ItemStack s8 = baseHexRelic(Items.ELYTRA, RelicType.FIM, "Relíquia do Fim", 0xE7E6B0);
        addEnchantment(s8, registries, Enchantments.PROTECTION, 15, false);
        s8.set(DataComponentTypes.LORE, new LoreComponent(List.of(Text.literal("Proteção 15").setStyle(Style.EMPTY.withColor(Formatting.GRAY).withItalic(false)))));
        list.add(s8);

        // 10. Slot 9 - Relíquia do Invasor (&8&l&o&nRelíquia do Invasor, Calça de Couro cinza, Binding Curse 1, Vanishing Curse 1, Protection 8, Mau Presságio 5)
        ItemStack s9 = baseRelic(Items.LEATHER_LEGGINGS, RelicType.INVASOR, "Relíquia do Invasor", Formatting.DARK_GRAY);
        s9.set(DataComponentTypes.DYED_COLOR, new DyedColorComponent(0x474F52, false));
        addEnchantment(s9, registries, Enchantments.BINDING_CURSE, 1, true);
        addEnchantment(s9, registries, Enchantments.VANISHING_CURSE, 1, true);
        addEnchantment(s9, registries, Enchantments.PROTECTION, 8, true);
        list.add(s9);

        // 11. Slot 10 - Relíquia da Imortalidade (<##2EEA7A>&l&o&nRelíquia da Imortalidade, Totem customizado com cooldown de 10s)
        ItemStack s10 = baseHexRelic(Items.TOTEM_OF_UNDYING, RelicType.IMORTALIDADE, "Relíquia da Imortalidade", 0x2EEA7A);
        s10.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        list.add(s10);

        // 12. Slot 11 - Relíquia do Oceano (&b&l&o&nRelíquia do Oceano, Tridente, Channeling 1, Sharpness 5, Impaling 10, Looting 3, Loyalty 3)
        ItemStack s11 = baseRelic(Items.TRIDENT, RelicType.OCEANO, "Relíquia do Oceano", Formatting.AQUA);
        addEnchantment(s11, registries, Enchantments.CHANNELING, 1, true);
        addEnchantment(s11, registries, Enchantments.SHARPNESS, 5, true);
        addEnchantment(s11, registries, Enchantments.IMPALING, 10, true);
        addEnchantment(s11, registries, Enchantments.LOOTING, 3, true);
        addEnchantment(s11, registries, Enchantments.LOYALTY, 3, true);
        list.add(s11);

        // 13. Slot 12 - Relíquia do Explorador (<##E0BE00>&l&o&nRelíquia do Explorador, Bota de Diamante, Frost Walker 2, lava vira magma 6x6 com quebra gradual)
        ItemStack s12 = baseHexRelic(Items.DIAMOND_BOOTS, RelicType.EXPLORADOR, "Relíquia do Explorador", 0xE0BE00);
        addEnchantment(s12, registries, Enchantments.FROST_WALKER, 2, true);
        list.add(s12);

        // 14. Slot 13 - Relíquia do Espião (<##C88D52>&l&o&nRelíquia do Espião, Biscoito, efeito espião 8min, cooldown 9min)
        ItemStack s13 = baseHexRelic(Items.COOKIE, RelicType.ESPIAO, "Relíquia do Espião", 0xC88D52);
        s13.remove(DataComponentTypes.FOOD);
        s13.remove(DataComponentTypes.CONSUMABLE);
        list.add(s13);

        // 15. Slot 14 - Relíquia do Deus do Vento (&f&l&o&nRelíquia do Deus do Vento, Carga de Vento infinita, solta 2)
        ItemStack s14 = baseRelic(Items.WIND_CHARGE, RelicType.DEUS_DO_VENTO, "Relíquia do Deus do Vento", Formatting.WHITE);
        list.add(s14);

        // 16. Slot 15 - Relíquia do Warden (&3&l&o&nRelíquia do Warden, Bússola de Recuperação, Sonic Boom 5 dano, cooldown 10s)
        ItemStack s15 = baseRelic(Items.RECOVERY_COMPASS, RelicType.WARDEN, "Relíquia do Warden", Formatting.DARK_AQUA);
        list.add(s15);

        // 17. Slot 16 - Relíquia do Stomper (&8&l&o&nRelíquia do Stomper, Clava, Density 5, Breach 4, Wind Burst 3, anula dano de queda)
        ItemStack s16 = baseRelic(Items.MACE, RelicType.STOMPER, "Relíquia do Stomper", Formatting.DARK_GRAY);
        addEnchantment(s16, registries, Enchantments.DENSITY, 5, false);
        addEnchantment(s16, registries, Enchantments.BREACH, 4, false);
        addEnchantment(s16, registries, Enchantments.WIND_BURST, 3, false);
        list.add(s16);

        // 18. Slot 17 - Relíquia do Dragão (<##7A2CFF>&l&o&nRelíquia do Dragão, Ovo do Dragão, teletransporte aleatório ao colocar ou usar, volta para o inventário)
        ItemStack s17 = baseHexRelic(Items.DRAGON_EGG, RelicType.DRAGAO, "Relíquia do Dragão", 0x7A2CFF);
        list.add(s17);

        // 19. Slot 18 - Relíquia da Invisibilidade (&f&l&o&nRelíquia da Invisibilidade, Bota de Couro cinza, Protection 10, invisível na 1ª e 3ª pessoa e armadura)
        ItemStack s18 = baseRelic(Items.LEATHER_BOOTS, RelicType.INVISIBILIDADE, "Relíquia da Invisibilidade", Formatting.WHITE);
        s18.set(DataComponentTypes.DYED_COLOR, new DyedColorComponent(0x9D9D97, false));
        addEnchantment(s18, registries, Enchantments.PROTECTION, 10, true);
        list.add(s18);

        // 20. Slot 19 - Relíquia do Nether (&6&l&o&nRelíquia do Nether, Capacete de Ouro, Protection 8, Cubo 5 e Resistência ao Fogo 5 infinitos)
        ItemStack s19 = baseRelic(Items.GOLDEN_HELMET, RelicType.NETHER, "Relíquia do Nether", Formatting.GOLD);
        addEnchantment(s19, registries, Enchantments.PROTECTION, 8, true);
        list.add(s19);

        return list;
    }
}
